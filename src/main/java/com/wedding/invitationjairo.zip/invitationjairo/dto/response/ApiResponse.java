package com.wedding.invitationjairo.dto.response;

public class ApiResponse {
    private boolean success;
    private String message;

    //Constructor 1
    public ApiResponse() {

    }

    //Constructor 2
    public ApiResponse(
        boolean success,
        String message
    ) {
        this.success = success;
        this.message = message;
    }

    public static ApiResponse ok(String message) {
        return new ApiResponse(true, message);
    }

    public static ApiResponse error(String message) {
        return new ApiResponse(false, message);
    }

    public boolean isSuccess(){
        return success;
    }
    
    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}